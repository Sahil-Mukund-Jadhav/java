package MethodsDemo;

public class Calculator {
	
	static void add() {
		System.out.println("Static add() from Calculator class");
	}

	
	 void sub() {
		System.out.println("non-static sub() from Calculator class");
	}
}
