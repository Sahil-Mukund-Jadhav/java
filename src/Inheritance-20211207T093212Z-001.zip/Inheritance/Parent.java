package Inheritance;

public class Parent {

	int age_of_p=30;
	
	void home() {
		System.out.println("Home () form parent class");
	}

	void car() {
		System.out.println("Car mehtod form parent");
	}
}
