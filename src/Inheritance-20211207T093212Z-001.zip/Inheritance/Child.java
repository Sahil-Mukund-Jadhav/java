package Inheritance;

public class Child extends Parent{

	int age_of_child=15;
	
	void bike() {
		System.out.println("Bike () from child class");
	}
}
