package Polymorphism;

public class Parent {
	
	void add(int a) {
		System.out.println("Addition method from Parent");
	}
	
	void sub() {
		System.out.println("Substraction method from Parent");
	}
}
