package Polymorphism;

public class Child extends Parent{

	void add(int z) {
		System.out.println("addition of two nos");
		System.out.println("add() form child");
	}
	
	void display() {
		System.out.println("display methd from child");
	}
}
